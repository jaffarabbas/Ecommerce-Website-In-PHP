<?php include("header.php") ?>

<!-- banner start -->
<section class="tmc_banner">
    <div class="container">
        <div class="row mini_banner_row">
            <div class="col-md-6 col-md-offset-3">
                <div class="mini_banner_center text-center">
                    <h1>Terms And Conditions</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- banner end -->

<!-- product start -->
<section class="termsCondionPage">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="tmc text-center">
                    <h1 class="secondaryHeading p">Terms & Conditions</h1>
                    <p class="primaryParagraph">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis facere error tenetur praesentium, odio facilis dolores et eos quisquam aliquid odit dolorem, velit voluptas eaque. Et deserunt totam voluptate enim nobis sit earum
                        aliquid officiis ipsam ipsa temporibus a assumenda sed minima nulla, cumque accusantium illo ratione quis, voluptatibus unde deleniti. Et nulla voluptates facere earum, nemo quod odit repudiandae quas dolores laboriosam error
                        molestiae provident dicta commodi unde minus sunt tempore ipsum ex necessitatibus. Eveniet nihil nobis sunt nam soluta iusto iure, nostrum corporis saepe ipsum architecto ut ducimus rem harum dolorem sed? Nisi voluptatem exercitationem
                        aspernatur vero quo commodi ducimus doloribus, nobis accusamus harum vel! Ad temporibus laborum, a eaque maiores incidunt praesentium inventore fuga blanditiis amet, placeat recusandae at delectus fugiat est officiis illum
                        quam? Cum, minima. Eaque natus perspiciatis aliquam tenetur laboriosam omnis assumenda nulla modi sapiente. Quas optio consectetur earum nisi voluptate aspernatur eaque sed, debitis recusandae nihil dicta quibusdam impedit
                        provident sunt id? Molestiae accusantium porro itaque ullam fugiat voluptatem sed expedita soluta nihil id ea enim blanditiis, nobis fugit molestias dignissimos maiores possimus. Officiis aliquam deserunt aliquid facilis id
                        tempora, iusto non consectetur voluptatum facere delectus nostrum eius, accusamus repellat omnis ad illo praesentium. Laborum sint dicta corporis voluptate harum, molestias ratione aperiam ad dolorem consequatur sit quos quibusdam
                        iure nobis qui consectetur amet tempora laboriosam cupiditate minima, maiores corrupti perferendis voluptatibus? Necessitatibus harum in at nisi, vel temporibus quae laborum nostrum excepturi dicta impedit, ut similique, iusto
                        consequatur delectus dolor tenetur corporis.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- product end -->

<?php include("footer.php") ?>