<?php 
include("dbOperations.php");
include("queries.php");
include("validation.php");
include("methods.php");
include("routes.php");
include("keywords.php");

$operations = new DbOperations();
error_reporting(E_ERROR | E_PARSE);
?>